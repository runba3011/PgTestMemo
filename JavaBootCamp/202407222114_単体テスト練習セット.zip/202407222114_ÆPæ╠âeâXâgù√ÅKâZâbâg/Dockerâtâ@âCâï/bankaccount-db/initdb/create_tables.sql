-- 生成されたソースは元のソースとは完全に一致しない場合があります。

--------------------------------------------------------------------------------
SET CHARSET utf8;
-- Table : bankaccoutdb.account_info
CREATE TABLE account_info (
  accountNo decimal(8,0) NOT NULL COMMENT '口座番号',
  pin decimal(4,0) NOT NULL COMMENT '暗証番号',
  holderName varchar(255) NOT NULL COMMENT '口座名義',
  balance decimal(30,0) NOT NULL COMMENT '口座残高',
  PRIMARY KEY (accountNo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='口座情報';