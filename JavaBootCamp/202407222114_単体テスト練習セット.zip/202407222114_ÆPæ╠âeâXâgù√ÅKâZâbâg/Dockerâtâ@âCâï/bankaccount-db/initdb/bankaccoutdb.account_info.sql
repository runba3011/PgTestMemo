SET CHARSET utf8;
insert into bankaccoutdb.account_info(accountNo,pin,holderName,balance) values 
 (11111111,1234,'山田太郎',451300)
,(12345678,4567,'高橋太郎',1050000)
,(22222222,2345,'佐藤太郎',260500)
,(33333333,3456,'鈴木太郎',999999)
,(99999999,9000,'田中太郎',99999999)
;
