package magic;
import magic.base.Magic;

public class LimitLessAo extends Magic {
  public LimitLessAo() {
    super("術式反転 蒼",1,"敵に 200 ～ 300 の防御無視ダメージ",200,300);
  }
}