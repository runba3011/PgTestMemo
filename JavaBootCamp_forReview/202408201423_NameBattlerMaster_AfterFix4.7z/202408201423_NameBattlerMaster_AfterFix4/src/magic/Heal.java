package magic;
import magic.base.MagicHeal;

public class Heal extends MagicHeal {
  public Heal() {
    super("ヒール",20,"HP を 50 回復",50,50);
  }
}