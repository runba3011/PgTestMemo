package magic;
import magic.base.Magic;

public class Fire extends Magic {
  public Fire() {
    super("ファイア", 10, "敵に 10 ～ 30 の防御無視ダメージ", 10, 30);
  }
}