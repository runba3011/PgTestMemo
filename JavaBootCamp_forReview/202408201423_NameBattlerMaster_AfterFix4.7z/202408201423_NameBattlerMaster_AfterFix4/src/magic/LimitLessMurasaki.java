package magic;
import magic.base.Magic;

public class LimitLessMurasaki extends Magic {
  public LimitLessMurasaki() {
    super("虚式 茈",2,"敵に 500 ～ 600 の防御無視ダメージ",500,600);
  }
}