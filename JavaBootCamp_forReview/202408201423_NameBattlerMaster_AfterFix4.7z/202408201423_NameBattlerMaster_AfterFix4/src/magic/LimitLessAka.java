package magic;
import magic.base.Magic;

public class LimitLessAka extends Magic {
  public LimitLessAka() {
    super("術式順転 赫",1,"敵に 100 ～ 200 の防御無視ダメージ",100,200);
  }
}