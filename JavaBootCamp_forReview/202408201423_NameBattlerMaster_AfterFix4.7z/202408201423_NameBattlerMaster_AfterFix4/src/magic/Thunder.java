package magic;
import magic.base.Magic;

public class Thunder extends Magic {
  public Thunder() {
    super("サンダー",20,"敵に 10 ～ 30 の防御無視ダメージ",10,30);
  }
}