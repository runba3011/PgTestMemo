public class Define {
  public final static int CAPTURE_RATE_MAX = 100;
  public final static int MONSTER_COUNT_MAX = 10;

  /** インスタンス化を避けるためのコンストラクタ */
  private Define(){

  }
}